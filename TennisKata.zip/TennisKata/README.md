#  Tennis Game Calculator 

What we need to run this application 
1. Xcode 
2. iOS 13.4 
3. Swift 5 


How to run this in simulator 
1. Open TennisKata.xcodeproj file in Xcode 
2. Select "TennisKata" target and select any iPhone simulator 
3. Build and Run 
It should run in iPhone simulator. 


How to use this application 

1. Once we launch the app, UI displays two text fields to type Players name 
2. After typing Players name, tap on 'Start Game' button 
2.1 Without providing Players name if we tap "Start Game" button 
2.2 Alert displays to type Players name  
2.3 Alert has 'OK' button, Once we tap 'OK' button, cursor moves to the empty text field 

3. Once "'Start Game' button tapped, it disabled
4. Displays couple of labels and picker to select who scored (every-time when player scored)
5. Picker has options with typed player name. User has to pick who has scored in the picker 
6. Based on who scored, score displays at the bottom, below "Score:" label 
7. Once we got winner. Picker stops taking user interactions 

8. While game is on, due to circumstance if we would like to reset the score. We can use "Reset" button to reset the score 
9. Or Once game is over. if we would like to start new game. We can tap "Reset' button 

10. If we would like start a game with new players, have to type new players name and tap 'Start Game' button 



