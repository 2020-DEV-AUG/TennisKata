//
//  ScoreCalculator.swift
//  TennisKata
//

//  Copyright © 2020 tennis. All rights reserved.
//

import UIKit

class ScoreCalculator: NSObject {
	var playerOneScore = 0
	var playerTwoScore = 0
	var playerOneName: String
	var playerTwoName: String
	
	init(playerOneName: String, playerTwoName: String) {
		self.playerOneName = playerOneName
		self.playerTwoName = playerTwoName
		super.init()
	}
	
	
	/// Method to calculate the score and returns respective strings of score or position of the game
	func getScore() -> String {
		if hasWinner() {
			return playerWithHighestScore() + " wins"
		}
		
		if hasAdvantage() {
			return playerWithHighestScore() + " has Advantage"
		}
		
		if deuce() {
			return "Deuce"
		}
		
		if(playerOneScore == playerTwoScore) {
			return translateScore(score: playerOneScore) + " All";
		}
		return translateScore(score: playerOneScore) + " -- " + translateScore(score: playerTwoScore);
	}
	
	/// Method to add points when player one scored
	func playerOneScored() {
		playerOneScore += 1
	}

	/// Method to add points when player two scored
	func playerTwoScored() {
		playerTwoScore += 1
	}
	
	
	/// Method returns whether we have winner or not
	func hasWinner()-> Bool {
		if playerTwoScore >= 4 && playerTwoScore >= playerOneScore + 2 {
			return true
		}
		if playerOneScore >= 4 && playerOneScore >= playerTwoScore + 2 {
			return true
		}
		return false
	}
	
	
	/// Method to return who has highest score on the board
	func playerWithHighestScore() -> String {
		if playerOneScore > playerTwoScore {
			return playerOneName
		} else {
			return playerTwoName
		}
	}
	
	/// Method to check any player has advantage or not
	func hasAdvantage() -> Bool {
		if (playerTwoScore >= 4 && playerTwoScore >= playerOneScore + 1) ||
			(playerOneScore >= 4 && playerOneScore >= playerTwoScore + 1) {
			return true
		}
		return false
	}
	
	/// Method to translate points into words
	func translateScore(score: Int) -> String {
		switch score {
			case 3:
			return "Forty"
			case 2:
			return "Thirty"
			case 1:
			return "Fifteen"
			case 0:
			return "Love"
			default:
			 print("Not a valid score")
		}
		return "Illegal score"
	}
	
	/// Method to check game is in deuce or not
	func deuce() -> Bool {
		return playerOneScore >= 3 && playerTwoScore == playerOneScore;
	}
}
