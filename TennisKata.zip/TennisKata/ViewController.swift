//
//  ViewController.swift
//  TennisKata
//

//  Copyright © 2020 tennis. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
	
	@IBOutlet weak var player1Name: UITextField!
	@IBOutlet weak var player2Name: UITextField!
	@IBOutlet weak var whoScoredPicker: UIPickerView!
	@IBOutlet weak var displayScoreLabel: UILabel!
	@IBOutlet weak var scoreLabel: UILabel!
	@IBOutlet weak var whoScoredLabel: UILabel!
	@IBOutlet weak var startGame: UIButton!
	@IBOutlet weak var reset: UIButton!
	
	var pickerData: [String] = [String]()
	// Initializing score calculator with dummy names
	var scoreCalculator = ScoreCalculator(playerOneName: "Player1", playerTwoName: "Player2")
	
	override func viewDidLoad() {
		super.viewDidLoad()
		whoScoredPicker.delegate = self
		whoScoredPicker.dataSource = self
		hideOrShowScoreDetails(isShow: true)
		player1Name.becomeFirstResponder()
	}
	
	/// Action method to start the game and displays score details
	@IBAction func startGame(_ sender: Any) {
		guard let playerOneName = player1Name.text,
			let playerTwoName = player2Name.text else {
				return
		}
		// Check whether user provided Player names, if not ask to provide
		if playerOneName.isEmpty || playerTwoName.isEmpty {
			DispatchQueue.main.async {
				let alertController = UIAlertController(title: "TennisKata", message:
					"Please type the name(s)", preferredStyle: .alert)
				alertController.addAction(UIAlertAction(title: "OK", style: .default))
				self.present(alertController, animated: true, completion: nil)
			}
			_ = player1Name.text!.isEmpty ? player1Name.becomeFirstResponder() : player2Name.becomeFirstResponder()
		} else {
			player2Name.resignFirstResponder()
			player1Name.resignFirstResponder()
			hideOrShowScoreDetails(isShow: false)
			pickerData = [playerOneName, playerTwoName]
			scoreCalculator.playerOneName = playerOneName
			scoreCalculator.playerTwoName = playerTwoName
			DispatchQueue.main.async {
				self.startGame.isEnabled = false
				self.whoScoredPicker.reloadAllComponents()
				self.whoScoredPicker.isUserInteractionEnabled = true
				self.displayScoreLabel.text = self.scoreCalculator.getScore()
			}
		}
	}
	
	/// Action method to reset the game score
	@IBAction func resetGameScore(_ sender: Any) {
		scoreCalculator.playerOneScore = 0
		scoreCalculator.playerTwoScore = 0
		hideOrShowScoreDetails(isShow: true)
		DispatchQueue.main.async {
			self.startGame.isEnabled = true
			self.displayScoreLabel.text = ""
		}
	}
	
	/// Method to hide/show labels and picker
	func hideOrShowScoreDetails(isShow: Bool) {
		DispatchQueue.main.async {
			self.whoScoredPicker.isHidden = isShow
			self.whoScoredLabel.isHidden = isShow
			self.displayScoreLabel.isHidden = isShow
			self.scoreLabel.isHidden = isShow
			self.displayScoreLabel.isHidden = isShow
		}
	}
	
	// MARK:- Picker Delegate and Data-Source methods
	
	func numberOfComponents(in pickerView: UIPickerView) -> Int {
		return 1
	}
	
	func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
		return pickerData.count
	}
	
	func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
		return pickerData[row]
	}
	
	func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
		if row == 0 {
			scoreCalculator.playerOneScored()
		} else {
			scoreCalculator.playerTwoScored()
		}
		let score = scoreCalculator.getScore()
		DispatchQueue.main.async {
			self.displayScoreLabel.text = score
			// If score contains "wins" string that means game completed, stop taking actions for the who scored picker
			if score.contains("wins") {
				self.whoScoredPicker.isUserInteractionEnabled = false
			}
		}
	}
}

